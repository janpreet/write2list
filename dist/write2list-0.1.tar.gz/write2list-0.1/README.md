![Build README](https://github.com/janpreet/janpreet/workflows/Build%20README/badge.svg) <br />### Hi there 👋  <br />Thank you for visiting my GitHub. Reach out to me at [singh@janpreet.com](mailto:singh@janpreet.com), read my [blog](https://janpreet.com) or follow [@SinghJanpreet](https://twitter.com/singhjanpreet) on Twitter. <br /><table style='float:right' markdown='1'><tr><th>Language Composition</th><th>Blog</th></tr><tr><td style='vertical-align:top'> 
- Dockerfile: 40.00% <br />
- HCL: 20.00% <br />
- HTML: 13.33% <br />
- Python: 13.33% <br />
- SCSS: 6.67% <br />
- TeX: 6.67% <br />
</td><td style='vertical-align:top'>
- <a href="https://janpreet.com/tech/2020/12/08/terraform-gcp-k8s.html" target="_blank">Terraform-GCP-K8s: A Jenkins DevOps story</a><br />
</td></tr></table>
<small><i>NOTE: Language composition is a list of most used languages in my repositories. It is not a direct indication of my skill level.</i></small>